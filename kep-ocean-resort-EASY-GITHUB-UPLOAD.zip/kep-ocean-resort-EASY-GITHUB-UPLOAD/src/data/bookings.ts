import type { BookingRequest, BookingRequestStatus } from '../types';
import { villas } from './villas';

interface Raw {
  fullName: string;
  phone: string;
  email: string;
  telegramOrWhatsapp?: string;
  villaId: string;
  checkIn: string;
  checkOut: string;
  adults: number;
  children: number;
  arrivalTime?: string;
  specialRequest?: string;
  status: BookingRequestStatus;
  internalNotes?: string;
  submittedDaysBeforeCheckIn: number;
}

const villaById = (id: string) => villas.find((v) => v.id === id)!;

// Local Y/M/D formatting avoids a UTC day-shift in timezones ahead of UTC
// (e.g. Cambodia) that toISOString() would introduce.
function toLocalISO(d: Date) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function build(raw: Raw[]): BookingRequest[] {
  return raw.map((r, i) => {
    const villa = villaById(r.villaId);
    const submitted = new Date(r.checkIn);
    submitted.setDate(submitted.getDate() - r.submittedDaysBeforeCheckIn);
    return {
      id: `KOR-2026-${String(i + 1).padStart(4, '0')}`,
      fullName: r.fullName,
      phone: r.phone,
      email: r.email,
      telegramOrWhatsapp: r.telegramOrWhatsapp,
      preferredVillaId: villa.id,
      preferredVillaName: villa.name,
      checkIn: r.checkIn,
      checkOut: r.checkOut,
      adults: r.adults,
      children: r.children,
      arrivalTime: r.arrivalTime,
      specialRequest: r.specialRequest,
      status: r.status,
      internalNotes: r.internalNotes,
      submittedAt: toLocalISO(submitted),
    };
  });
}

// Anchor "today" for this demo dataset is 2026-07-24.
const bookingsRaw: Raw[] = [
  { fullName: 'Chan Sreymom', phone: '+855 92 444 210', email: 'chan.sreymom@example.com', telegramOrWhatsapp: '@sreymom_c', villaId: 'v1', checkIn: '2026-07-29', checkOut: '2026-08-02', adults: 2, children: 0, arrivalTime: '15:30', specialRequest: 'High floor if possible', status: 'Confirmed', internalNotes: 'Confirmed by phone, deposit to be paid on arrival.', submittedDaysBeforeCheckIn: 6 },
  { fullName: 'Emily Carter', phone: '+1 415 555 0192', email: 'emily.carter@example.com', villaId: 'v8', checkIn: '2026-08-02', checkOut: '2026-08-06', adults: 2, children: 0, specialRequest: 'Anniversary — hoping for a quiet villa', status: 'New', submittedDaysBeforeCheckIn: 5 },
  { fullName: 'Isabella Rossi', phone: '+39 320 123 4567', email: 'isabella.rossi@example.com', telegramOrWhatsapp: '@bella_rossi', villaId: 'v4', checkIn: '2026-08-10', checkOut: '2026-08-13', adults: 2, children: 0, status: 'Contacted', internalNotes: 'Messaged on Telegram, awaiting reply on dates.', submittedDaysBeforeCheckIn: 9 },
  { fullName: 'Grace Kim', phone: '+82 10 2345 6789', email: 'grace.kim@example.com', villaId: 'v3', checkIn: '2026-07-29', checkOut: '2026-08-02', adults: 2, children: 2, arrivalTime: '13:00', status: 'Contacted', internalNotes: 'Called, checking villa availability for those dates.', submittedDaysBeforeCheckIn: 4 },
  { fullName: 'Sok Dara', phone: '+855 12 555 101', email: 'sok.dara@example.com', villaId: 'v1', checkIn: '2026-07-24', checkOut: '2026-07-27', adults: 2, children: 0, arrivalTime: '15:30', status: 'Completed', internalNotes: 'Stayed and checked out, great feedback.', submittedDaysBeforeCheckIn: 14 },
  { fullName: 'Heng Vibol', phone: '+855 77 333 456', email: 'heng.vibol@example.com', villaId: 'v2', checkIn: '2026-06-16', checkOut: '2026-06-19', adults: 2, children: 1, status: 'Completed', submittedDaysBeforeCheckIn: 8 },
  { fullName: 'James Whitfield', phone: '+44 7700 900123', email: 'james.whitfield@example.com', telegramOrWhatsapp: '+44 7700 900123', villaId: 'v1', checkIn: '2026-06-01', checkOut: '2026-06-04', adults: 2, children: 0, status: 'Completed', submittedDaysBeforeCheckIn: 15 },
  { fullName: 'Marc Dubois', phone: '+33 6 98 76 54 32', email: 'marc.dubois@example.com', villaId: 'v4', checkIn: '2026-08-15', checkOut: '2026-08-18', adults: 2, children: 0, specialRequest: 'Late check-in around 22:00', status: 'New', submittedDaysBeforeCheckIn: 1 },
  { fullName: 'Daniel Kruger', phone: '+49 151 2345 6789', email: 'daniel.kruger@example.com', villaId: 'v7', checkIn: '2026-08-05', checkOut: '2026-08-07', adults: 2, children: 0, status: 'Cancelled', internalNotes: 'Guest cancelled due to flight change.', submittedDaysBeforeCheckIn: 15 },
  { fullName: 'Ly Sophea', phone: '+855 15 678 901', email: 'ly.sophea@example.com', telegramOrWhatsapp: '@lysophea', villaId: 'v8', checkIn: '2026-08-20', checkOut: '2026-08-24', adults: 2, children: 2, specialRequest: 'Traveling with grandparents, ground floor preferred', status: 'Contacted', internalNotes: 'Sent WhatsApp message with villa photos.', submittedDaysBeforeCheckIn: 12 },
  { fullName: 'Oliver Bennett', phone: '+61 412 345 678', email: 'oliver.bennett@example.com', villaId: 'v1', checkIn: '2026-07-24', checkOut: '2026-07-25', adults: 2, children: 0, arrivalTime: '14:45', status: 'Confirmed', internalNotes: 'Confirmed, arriving today.', submittedDaysBeforeCheckIn: 4 },
  { fullName: 'Pich Chanthy', phone: '+855 88 222 333', email: 'pich.chanthy@example.com', villaId: 'v5', checkIn: '2026-08-01', checkOut: '2026-08-03', adults: 2, children: 0, status: 'Cancelled', internalNotes: 'No response after multiple attempts to contact.', submittedDaysBeforeCheckIn: 0 },
  { fullName: 'Kenji Nakamura', phone: '+81 90 1234 5678', email: 'kenji.nakamura@example.com', villaId: 'v5', checkIn: '2026-07-03', checkOut: '2026-07-06', adults: 2, children: 0, status: 'Completed', submittedDaysBeforeCheckIn: 18 },
  { fullName: 'Thida Sok', phone: '+855 96 111 222', email: 'thida.sok@example.com', telegramOrWhatsapp: '@thida_sok', villaId: 'v6', checkIn: '2026-07-26', checkOut: '2026-07-28', adults: 2, children: 1, arrivalTime: '16:00', status: 'New', submittedDaysBeforeCheckIn: 2 },
  { fullName: 'Mei Ling Tan', phone: '+65 8123 4567', email: 'meiling.tan@example.com', villaId: 'v6', checkIn: '2026-03-28', checkOut: '2026-03-30', adults: 2, children: 0, status: 'Completed', submittedDaysBeforeCheckIn: 12 },
  { fullName: 'Sophie Laurent', phone: '+33 6 12 34 56 78', email: 'sophie.laurent@example.com', villaId: 'v4', checkIn: '2026-05-12', checkOut: '2026-05-15', adults: 2, children: 0, specialRequest: 'Celebrating anniversary — romantic setup if possible', status: 'Completed', submittedDaysBeforeCheckIn: 30 },
];

export const bookings: BookingRequest[] = build(bookingsRaw);

export const getBookingById = (id: string) => bookings.find((b) => b.id === id);
