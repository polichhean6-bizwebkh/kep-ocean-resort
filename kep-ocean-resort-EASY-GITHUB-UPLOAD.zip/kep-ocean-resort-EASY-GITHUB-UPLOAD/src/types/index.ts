// Shared TypeScript types for Kep Ocean Resort demo.
// NOTE: This is a frontend demo. In production these types would mirror
// a real backend/database schema shared via generated API types.

export type ViewType = 'Ocean View' | 'Garden View' | 'Pool View' | 'Sunset View';

export interface Villa {
  id: string;
  code: string;
  slug: string;
  name: string;
  type: string;
  shortDescription: string;
  fullDescription: string;
  images: string[];
  maxGuests: number;
  beds: string;
  bathrooms: number;
  sizeSqm: number;
  view: ViewType;
  amenities: string[];
  houseRules: string[];
  pricePerNight: number;
  status: 'Available' | 'Reserved' | 'Occupied' | 'Cleaning' | 'Maintenance' | 'Blocked';
  cleaningStatus: 'Clean' | 'Cleaning' | 'Needs Cleaning';
  maintenanceNote?: string;
  currentGuest?: string;
  featured?: boolean;
}

// Simple booking REQUEST — the customer submits interest in a stay, and
// resort staff manually follow up to confirm availability and payment.
// There is intentionally no pricing, payment, or extras data here: this
// demo covers "receive and manage booking requests" only.
export type BookingRequestStatus = 'New' | 'Contacted' | 'Confirmed' | 'Cancelled' | 'Completed';

export interface BookingRequest {
  id: string; // e.g. KOR-2026-0001
  fullName: string;
  phone: string;
  email: string;
  telegramOrWhatsapp?: string;
  preferredVillaId: string;
  preferredVillaName: string;
  checkIn: string; // ISO date
  checkOut: string; // ISO date
  adults: number;
  children: number;
  arrivalTime?: string;
  specialRequest?: string;
  status: BookingRequestStatus;
  internalNotes?: string;
  submittedAt: string; // ISO date
}

export type MenuCategory =
  | 'Breakfast'
  | 'Khmer Food'
  | 'Seafood'
  | 'Western Food'
  | 'Snacks'
  | 'Cocktails'
  | 'Beer'
  | 'Wine'
  | 'Soft Drinks'
  | 'Juice'
  | 'Coffee';

export interface MenuItem {
  id: string;
  name: string;
  category: MenuCategory;
  price: number;
  image: string;
  description: string;
  available: boolean;
}

export interface Experience {
  id: string;
  name: string;
  image: string;
  description: string;
  operatedByResort: boolean;
}

export interface Review {
  id: string;
  guestName: string;
  country: string;
  rating: number;
  review: string;
  stayType: string;
  date: string;
}

export interface GalleryImage {
  id: string;
  src: string;
  category: 'Villas' | 'Food' | 'Bar' | 'Ocean' | 'Experiences';
  alt: string;
}
