import { createContext, useContext, useState, type ReactNode } from 'react';
import type { BookingRequest } from '../types';
import { bookings as seedBookings } from '../data/bookings';

interface AppDataContextValue {
  bookings: BookingRequest[];
  addBooking: (booking: BookingRequest) => void;
  updateBooking: (id: string, patch: Partial<BookingRequest>) => void;
  deleteBooking: (id: string) => void;
  resetDemoData: () => void;
  lastReset: string | null;
}

const AppDataContext = createContext<AppDataContextValue | undefined>(undefined);

// In-memory app data store for this demo. Booking requests submitted through
// the public website during the browser session are added here so they
// immediately appear in the admin dashboard, without any backend/database in
// place yet. "Reset Demo Data" in Settings restores the original sample list.
export function AppDataProvider({ children }: { children: ReactNode }) {
  const [bookings, setBookings] = useState<BookingRequest[]>(seedBookings);
  const [lastReset, setLastReset] = useState<string | null>(null);

  const addBooking = (booking: BookingRequest) => setBookings((prev) => [booking, ...prev]);
  const updateBooking = (id: string, patch: Partial<BookingRequest>) =>
    setBookings((prev) => prev.map((b) => (b.id === id ? { ...b, ...patch } : b)));
  const deleteBooking = (id: string) => setBookings((prev) => prev.filter((b) => b.id !== id));

  const resetDemoData = () => {
    setBookings(seedBookings);
    setLastReset(new Date().toLocaleString());
  };

  return (
    <AppDataContext.Provider value={{ bookings, addBooking, updateBooking, deleteBooking, resetDemoData, lastReset }}>
      {children}
    </AppDataContext.Provider>
  );
}

export function useAppData() {
  const ctx = useContext(AppDataContext);
  if (!ctx) throw new Error('useAppData must be used within AppDataProvider');
  return ctx;
}
