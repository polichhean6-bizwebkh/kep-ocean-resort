import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';
import { useAppData } from '../../context/AppDataContext';
import { villas } from '../../data/villas';
import type { BookingRequestStatus } from '../../types';

const statuses: BookingRequestStatus[] = ['New', 'Contacted', 'Confirmed', 'Cancelled', 'Completed'];

const statusDot: Record<BookingRequestStatus, string> = {
  New: 'bg-charcoal-400',
  Contacted: 'bg-sand-500',
  Confirmed: 'bg-turquoise-600',
  Cancelled: 'bg-red-500',
  Completed: 'bg-ocean-600',
};

const statusChip: Record<BookingRequestStatus, string> = {
  New: 'bg-charcoal-100 text-charcoal-700',
  Contacted: 'bg-sand-200 text-sand-900',
  Confirmed: 'bg-turquoise-100 text-turquoise-800',
  Cancelled: 'bg-red-100 text-red-700',
  Completed: 'bg-ocean-100 text-ocean-800',
};

const weekdayLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

function toISO(d: Date) {
  // Build the date string from local Y/M/D components (not toISOString, which
  // converts to UTC and can shift the date by a day in timezones ahead of UTC,
  // e.g. Cambodia). This keeps the calendar day matching the checkIn date exactly.
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export default function CalendarPage() {
  const { bookings } = useAppData();
  const [monthCursor, setMonthCursor] = useState(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });
  const [villaFilter, setVillaFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState<BookingRequestStatus | 'All'>('All');
  const [expandedDay, setExpandedDay] = useState<string | null>(null);

  const filtered = useMemo(() => {
    return bookings.filter((b) => {
      if (villaFilter !== 'All' && b.preferredVillaId !== villaFilter) return false;
      if (statusFilter !== 'All' && b.status !== statusFilter) return false;
      return true;
    });
  }, [bookings, villaFilter, statusFilter]);

  const bookingsByDate = useMemo(() => {
    const map: Record<string, typeof filtered> = {};
    filtered.forEach((b) => {
      (map[b.checkIn] ??= []).push(b);
    });
    return map;
  }, [filtered]);

  const monthLabel = monthCursor.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  const days = useMemo(() => {
    const year = monthCursor.getFullYear();
    const month = monthCursor.getMonth();
    const firstOfMonth = new Date(year, month, 1);
    // Monday-first offset
    const startOffset = (firstOfMonth.getDay() + 6) % 7;
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    const cells: { date: Date | null; iso: string | null }[] = [];
    for (let i = 0; i < startOffset; i++) cells.push({ date: null, iso: null });
    for (let d = 1; d <= daysInMonth; d++) {
      const date = new Date(year, month, d);
      cells.push({ date, iso: toISO(date) });
    }
    while (cells.length % 7 !== 0) cells.push({ date: null, iso: null });
    return cells;
  }, [monthCursor]);

  const todayISO = toISO(new Date());
  const goToday = () => {
    const d = new Date();
    setMonthCursor(new Date(d.getFullYear(), d.getMonth(), 1));
  };
  const prevMonth = () => setMonthCursor((m) => new Date(m.getFullYear(), m.getMonth() - 1, 1));
  const nextMonth = () => setMonthCursor((m) => new Date(m.getFullYear(), m.getMonth() + 1, 1));

  const expandedBookings = expandedDay ? bookingsByDate[expandedDay] ?? [] : [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-charcoal-900">Calendar</h1>
        <p className="text-charcoal-500 text-sm">Booking requests shown on their check-in date.</p>
      </div>

      <div className="bg-white rounded-2xl border border-charcoal-100 p-4 flex flex-col sm:flex-row sm:items-center gap-3 sm:justify-between">
        <div className="flex items-center gap-2">
          <button onClick={prevMonth} aria-label="Previous month" className="p-2 rounded-lg border border-charcoal-200 hover:bg-sand-50"><ChevronLeft className="h-4 w-4" /></button>
          <span className="text-sm font-semibold text-charcoal-900 w-40 text-center">{monthLabel}</span>
          <button onClick={nextMonth} aria-label="Next month" className="p-2 rounded-lg border border-charcoal-200 hover:bg-sand-50"><ChevronRight className="h-4 w-4" /></button>
          <button onClick={goToday} className="text-xs font-medium text-ocean-700 border border-ocean-200 rounded-lg px-3 py-2 hover:bg-ocean-50">Today</button>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <select value={villaFilter} onChange={(e) => setVillaFilter(e.target.value)} className="border border-charcoal-200 rounded-lg px-3 py-2 text-sm">
            <option value="All">All Villas</option>
            {villas.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}
          </select>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as BookingRequestStatus | 'All')} className="border border-charcoal-200 rounded-lg px-3 py-2 text-sm">
            <option value="All">All Statuses</option>
            {statuses.map((s) => <option key={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-charcoal-100 p-3 sm:p-4">
        <div className="grid grid-cols-7 gap-1 sm:gap-2 mb-1 sm:mb-2">
          {weekdayLabels.map((w) => (
            <div key={w} className="text-center text-[10px] sm:text-xs font-medium text-charcoal-400 py-1">{w}</div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1 sm:gap-2">
          {days.map((cell, i) => {
            if (!cell.date || !cell.iso) return <div key={i} className="min-h-[64px] sm:min-h-[104px]" />;
            const dayBookings = bookingsByDate[cell.iso] ?? [];
            const isToday = cell.iso === todayISO;
            const visible = dayBookings.slice(0, 2);
            const overflow = dayBookings.length - visible.length;

            return (
              <div
                key={i}
                className={`min-h-[64px] sm:min-h-[104px] rounded-lg sm:rounded-xl border p-1 sm:p-2 flex flex-col gap-1 ${isToday ? 'border-ocean-400 bg-ocean-50/40' : 'border-charcoal-100'}`}
              >
                <span className={`text-[10px] sm:text-xs font-medium ${isToday ? 'text-ocean-700' : 'text-charcoal-500'}`}>{cell.date.getDate()}</span>

                {/* Mobile: compact dots */}
                <div className="flex sm:hidden flex-wrap gap-0.5">
                  {dayBookings.slice(0, 4).map((b) => (
                    <span key={b.id} className={`h-1.5 w-1.5 rounded-full ${statusDot[b.status]}`} />
                  ))}
                </div>
                {dayBookings.length > 0 && (
                  <button
                    onClick={() => setExpandedDay(cell.iso)}
                    className="sm:hidden text-[10px] text-ocean-700 font-medium text-left"
                  >
                    {dayBookings.length} request{dayBookings.length !== 1 ? 's' : ''}
                  </button>
                )}

                {/* Desktop/tablet: inline chips */}
                <div className="hidden sm:flex flex-col gap-1">
                  {visible.map((b) => (
                    <Link
                      key={b.id}
                      to={`/admin/bookings/${b.id}`}
                      className={`block truncate rounded px-1.5 py-1 text-[10px] leading-tight font-medium ${statusChip[b.status]}`}
                      title={`${b.id} — ${b.fullName} — ${b.preferredVillaName}`}
                    >
                      {b.id} · {b.fullName}
                    </Link>
                  ))}
                  {overflow > 0 && (
                    <button onClick={() => setExpandedDay(cell.iso)} className="text-[10px] text-ocean-700 font-medium text-left px-1.5">
                      +{overflow} more
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-4 text-xs text-charcoal-500">
        {statuses.map((s) => (
          <span key={s} className="flex items-center gap-1.5"><span className={`h-2.5 w-2.5 rounded-full ${statusDot[s]}`} /> {s}</span>
        ))}
      </div>

      {expandedDay && (
        <div className="fixed inset-0 z-[100] bg-black/50 flex items-end sm:items-center justify-center p-4" onClick={() => setExpandedDay(null)}>
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full max-h-[80vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-lg font-semibold">
                {new Date(expandedDay + 'T00:00:00').toLocaleDateString('en-US', { weekday: 'long', day: 'numeric', month: 'long' })}
              </h3>
              <button onClick={() => setExpandedDay(null)} aria-label="Close"><X className="h-5 w-5 text-charcoal-400" /></button>
            </div>
            {expandedBookings.length === 0 ? (
              <p className="text-sm text-charcoal-400">No booking requests on this date.</p>
            ) : (
              <div className="space-y-2">
                {expandedBookings.map((b) => (
                  <Link
                    key={b.id}
                    to={`/admin/bookings/${b.id}`}
                    className="block border border-charcoal-100 rounded-xl p-3 hover:border-ocean-300"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-ocean-700">{b.id}</span>
                      <span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${statusChip[b.status]}`}>{b.status}</span>
                    </div>
                    <p className="text-sm text-charcoal-900">{b.fullName}</p>
                    <p className="text-xs text-charcoal-500">{b.preferredVillaName}</p>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
