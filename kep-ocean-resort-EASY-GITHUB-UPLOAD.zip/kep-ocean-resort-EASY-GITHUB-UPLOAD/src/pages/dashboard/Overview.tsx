import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Sparkles, PhoneCall, CheckCircle2, Ban } from 'lucide-react';
import { useAppData } from '../../context/AppDataContext';
import StatCard from '../../components/dashboard/StatCard';
import Badge from '../../components/ui/Badge';
import { formatDateShort } from '../../lib/format';

export default function Overview() {
  const { bookings } = useAppData();

  const stats = useMemo(() => {
    const total = bookings.length;
    const newCount = bookings.filter((b) => b.status === 'New').length;
    const contacted = bookings.filter((b) => b.status === 'Contacted').length;
    const confirmed = bookings.filter((b) => b.status === 'Confirmed').length;
    const cancelled = bookings.filter((b) => b.status === 'Cancelled').length;
    return { total, newCount, contacted, confirmed, cancelled };
  }, [bookings]);

  const recentBookings = [...bookings]
    .sort((a, b) => (a.submittedAt < b.submittedAt ? 1 : -1))
    .slice(0, 8);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-2xl font-semibold text-charcoal-900">Overview</h1>
        <p className="text-charcoal-500 text-sm">A quick look at incoming booking requests.</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <StatCard label="Total Requests" value={stats.total} icon={BookOpen} tone="ocean" />
        <StatCard label="New" value={stats.newCount} icon={Sparkles} tone="sand" />
        <StatCard label="Contacted" value={stats.contacted} icon={PhoneCall} tone="ocean" />
        <StatCard label="Confirmed" value={stats.confirmed} icon={CheckCircle2} tone="turquoise" />
        <StatCard label="Cancelled" value={stats.cancelled} icon={Ban} tone="red" />
      </div>

      <div className="bg-white rounded-2xl border border-charcoal-100 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-charcoal-900">Recent Booking Requests</h3>
          <Link to="/admin/bookings" className="text-xs font-medium text-ocean-700 hover:underline">View all</Link>
        </div>

        {/* Desktop table */}
        <div className="hidden sm:block overflow-x-auto">
          <table className="w-full text-sm min-w-[560px]">
            <thead>
              <tr className="text-left text-xs text-charcoal-400 border-b border-charcoal-100">
                <th className="py-2 font-medium">Reference</th>
                <th className="py-2 font-medium">Customer</th>
                <th className="py-2 font-medium">Villa</th>
                <th className="py-2 font-medium">Check-in</th>
                <th className="py-2 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {recentBookings.map((b) => (
                <tr key={b.id} className="border-b border-charcoal-50 last:border-0">
                  <td className="py-2.5"><Link to={`/admin/bookings/${b.id}`} className="text-ocean-700 font-medium hover:underline">{b.id}</Link></td>
                  <td className="py-2.5">{b.fullName}</td>
                  <td className="py-2.5 text-charcoal-500">{b.preferredVillaName}</td>
                  <td className="py-2.5">{formatDateShort(b.checkIn)}</td>
                  <td className="py-2.5"><Badge>{b.status}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile cards */}
        <div className="sm:hidden space-y-3">
          {recentBookings.map((b) => (
            <Link key={b.id} to={`/admin/bookings/${b.id}`} className="block border border-charcoal-100 rounded-xl p-3">
              <div className="flex items-center justify-between mb-1">
                <span className="text-ocean-700 font-medium text-sm">{b.id}</span>
                <Badge>{b.status}</Badge>
              </div>
              <p className="text-sm font-medium text-charcoal-900">{b.fullName}</p>
              <p className="text-xs text-charcoal-500">{b.preferredVillaName} · {formatDateShort(b.checkIn)}</p>
            </Link>
          ))}
        </div>

        {recentBookings.length === 0 && <p className="text-sm text-charcoal-400 text-center py-6">No booking requests yet.</p>}
      </div>
    </div>
  );
}
