import { useState } from 'react';
import { Info, RotateCcw } from 'lucide-react';
import { resortConfig, demoDisclaimer } from '../../data/resortConfig';
import { Button } from '../../components/ui/Button';
import ConfirmDialog from '../../components/dashboard/ConfirmDialog';
import { useAppData } from '../../context/AppDataContext';

export default function SettingsAdmin() {
  const [form, setForm] = useState({
    checkIn: resortConfig.contact.checkIn,
    checkOut: resortConfig.contact.checkOut,
    confirmationMessage: resortConfig.policies.confirmationMessage,
    language: 'English',
  });
  const [saved, setSaved] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [resetDone, setResetDone] = useState(false);
  const { resetDemoData, lastReset } = useAppData();

  const handleReset = () => {
    resetDemoData();
    setConfirmReset(false);
    setResetDone(true);
    setTimeout(() => setResetDone(false), 3000);
  };

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="font-display text-2xl font-semibold text-charcoal-900">Settings</h1>
        <p className="text-charcoal-500 text-sm">Basic resort configuration for this demo.</p>
      </div>

      <div className="bg-white rounded-2xl border border-charcoal-100 p-6 space-y-5">
        <h3 className="font-semibold text-charcoal-900">Resort & Contact Information</h3>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div><label className="block text-xs text-charcoal-500 mb-1">Resort Name</label><input defaultValue={resortConfig.name} className="w-full border border-charcoal-200 rounded-lg px-3 py-2" /></div>
          <div><label className="block text-xs text-charcoal-500 mb-1">Phone</label><input defaultValue={resortConfig.contact.phone} className="w-full border border-charcoal-200 rounded-lg px-3 py-2" /></div>
        </div>

        <h3 className="font-semibold text-charcoal-900 pt-2">Check-in / Check-out</h3>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div><label className="block text-xs text-charcoal-500 mb-1">Check-in Time</label><input type="time" value={form.checkIn} onChange={(e) => setForm({ ...form, checkIn: e.target.value })} className="w-full border border-charcoal-200 rounded-lg px-3 py-2" /></div>
          <div><label className="block text-xs text-charcoal-500 mb-1">Check-out Time</label><input type="time" value={form.checkOut} onChange={(e) => setForm({ ...form, checkOut: e.target.value })} className="w-full border border-charcoal-200 rounded-lg px-3 py-2" /></div>
        </div>

        <h3 className="font-semibold text-charcoal-900 pt-2">Booking Confirmation Message</h3>
        <textarea value={form.confirmationMessage} onChange={(e) => setForm({ ...form, confirmationMessage: e.target.value })} rows={3} className="w-full border border-charcoal-200 rounded-lg px-3 py-2 text-sm" />
        <p className="text-xs text-charcoal-400 -mt-3">Shown to customers on the booking confirmation screen after they submit a request.</p>

        <h3 className="font-semibold text-charcoal-900 pt-2">Language</h3>
        <select value={form.language} onChange={(e) => setForm({ ...form, language: e.target.value })} className="w-full border border-charcoal-200 rounded-lg px-3 py-2 text-sm">
          <option>English</option>
          <option>Khmer</option>
        </select>

        <Button onClick={handleSave}>{saved ? 'Saved ✓' : 'Save Settings'}</Button>
      </div>

      <div className="bg-white rounded-2xl border border-charcoal-100 p-6 space-y-3">
        <h3 className="font-semibold text-charcoal-900">Demo Data</h3>
        <p className="text-sm text-charcoal-600">
          This demo uses sample booking requests so you can freely test the dashboard. If sample
          data gets out of order while testing, you can restore it to its original state at any
          time. This only resets sample data — it does not affect the public website design.
        </p>
        <Button variant="outlineLight" size="sm" onClick={() => setConfirmReset(true)}>
          <RotateCcw className="h-4 w-4" /> Reset Demo Data
        </Button>
        {resetDone && <p className="text-xs text-turquoise-700 font-medium">Demo data has been restored to its original sample state.</p>}
        {!resetDone && lastReset && <p className="text-xs text-charcoal-400">Last reset: {lastReset}</p>}
      </div>

      <div className="flex items-start gap-2 bg-sand-50 border border-sand-200 rounded-lg px-4 py-3 text-xs text-charcoal-600">
        <Info className="h-4 w-4 shrink-0 mt-0.5 text-ocean-700" />
        {demoDisclaimer}
      </div>

      <ConfirmDialog
        open={confirmReset}
        title="Reset demo data?"
        message="This restores the original sample booking requests for this demo. It resets sample data only — it does not affect the public website design or any source files. This action cannot be undone."
        confirmLabel="Reset Demo Data"
        onConfirm={handleReset}
        onCancel={() => setConfirmReset(false)}
      />
    </div>
  );
}
