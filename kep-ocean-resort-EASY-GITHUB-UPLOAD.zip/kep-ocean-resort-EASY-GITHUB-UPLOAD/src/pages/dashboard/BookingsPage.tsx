import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Eye, Trash2 } from 'lucide-react';
import { useAppData } from '../../context/AppDataContext';
import Badge from '../../components/ui/Badge';
import ConfirmDialog from '../../components/dashboard/ConfirmDialog';
import { formatDateShort } from '../../lib/format';
import type { BookingRequestStatus } from '../../types';

const statuses: (BookingRequestStatus | 'All')[] = ['All', 'New', 'Contacted', 'Confirmed', 'Cancelled', 'Completed'];

export default function BookingsPage() {
  const { bookings, deleteBooking } = useAppData();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState<BookingRequestStatus | 'All'>('All');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    return bookings.filter((b) => {
      if (status !== 'All' && b.status !== status) return false;
      if (fromDate && b.checkIn < fromDate) return false;
      if (toDate && b.checkIn > toDate) return false;
      if (search && !b.fullName.toLowerCase().includes(search.toLowerCase()) && !b.id.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [bookings, status, fromDate, toDate, search]);

  const handleDelete = () => {
    if (deleteId) deleteBooking(deleteId);
    setDeleteId(null);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-charcoal-900">Booking Requests</h1>
        <p className="text-charcoal-500 text-sm">{filtered.length} of {bookings.length} requests</p>
      </div>

      <div className="bg-white rounded-2xl border border-charcoal-100 p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <label className="relative">
          <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-charcoal-400" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search name or reference" className="w-full border border-charcoal-200 rounded-lg pl-9 pr-3 py-2 text-sm" />
        </label>
        <select value={status} onChange={(e) => setStatus(e.target.value as BookingRequestStatus | 'All')} className="border border-charcoal-200 rounded-lg px-3 py-2 text-sm">
          {statuses.map((s) => <option key={s}>{s}</option>)}
        </select>
        <label className="flex items-center gap-2 text-xs text-charcoal-500">
          From <input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} className="flex-1 border border-charcoal-200 rounded-lg px-2 py-2 text-sm" />
        </label>
        <label className="flex items-center gap-2 text-xs text-charcoal-500">
          To <input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} className="flex-1 border border-charcoal-200 rounded-lg px-2 py-2 text-sm" />
        </label>
      </div>

      {/* Desktop table */}
      <div className="hidden lg:block bg-white rounded-2xl border border-charcoal-100 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-charcoal-400 border-b border-charcoal-100">
              <th className="py-3 px-4 font-medium">Reference</th>
              <th className="py-3 px-4 font-medium">Customer</th>
              <th className="py-3 px-4 font-medium">Phone</th>
              <th className="py-3 px-4 font-medium">Villa</th>
              <th className="py-3 px-4 font-medium">Check-in</th>
              <th className="py-3 px-4 font-medium">Check-out</th>
              <th className="py-3 px-4 font-medium">Guests</th>
              <th className="py-3 px-4 font-medium">Submitted</th>
              <th className="py-3 px-4 font-medium">Status</th>
              <th className="py-3 px-4 font-medium"></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((b) => (
              <tr key={b.id} className="border-b border-charcoal-50 last:border-0 hover:bg-sand-50/50">
                <td className="py-3 px-4 font-medium text-ocean-700">{b.id}</td>
                <td className="py-3 px-4">{b.fullName}</td>
                <td className="py-3 px-4 text-charcoal-500">{b.phone}</td>
                <td className="py-3 px-4 text-charcoal-500">{b.preferredVillaName}</td>
                <td className="py-3 px-4">{formatDateShort(b.checkIn)}</td>
                <td className="py-3 px-4">{formatDateShort(b.checkOut)}</td>
                <td className="py-3 px-4">{b.adults + b.children}</td>
                <td className="py-3 px-4 text-charcoal-500">{formatDateShort(b.submittedAt)}</td>
                <td className="py-3 px-4"><Badge>{b.status}</Badge></td>
                <td className="py-3 px-4">
                  <div className="flex items-center gap-3">
                    <Link to={`/admin/bookings/${b.id}`} className="inline-flex items-center gap-1 text-xs font-medium text-ocean-700 hover:underline">
                      <Eye className="h-3.5 w-3.5" /> View
                    </Link>
                    <button onClick={() => setDeleteId(b.id)} className="inline-flex items-center gap-1 text-xs font-medium text-red-600 hover:underline">
                      <Trash2 className="h-3.5 w-3.5" /> Delete
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile cards */}
      <div className="lg:hidden space-y-3">
        {filtered.map((b) => (
          <div key={b.id} className="bg-white rounded-2xl border border-charcoal-100 p-4">
            <Link to={`/admin/bookings/${b.id}`} className="block">
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium text-ocean-700 text-sm">{b.id}</span>
                <Badge>{b.status}</Badge>
              </div>
              <p className="font-medium text-charcoal-900">{b.fullName}</p>
              <p className="text-sm text-charcoal-500 mb-2">{b.preferredVillaName}</p>
              <div className="flex items-center justify-between text-xs text-charcoal-500">
                <span>{formatDateShort(b.checkIn)} → {formatDateShort(b.checkOut)}</span>
                <span>{b.adults + b.children} guests</span>
              </div>
            </Link>
            <button onClick={() => setDeleteId(b.id)} className="mt-3 inline-flex items-center gap-1 text-xs font-medium text-red-600">
              <Trash2 className="h-3.5 w-3.5" /> Delete
            </button>
          </div>
        ))}
      </div>

      {filtered.length === 0 && <p className="text-center text-charcoal-400 py-10">No booking requests match your filters.</p>}

      <ConfirmDialog
        open={!!deleteId}
        title="Delete this demo booking?"
        message="This permanently removes the booking request from this demo session. This does not affect any real customer data."
        confirmLabel="Delete Booking"
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}
