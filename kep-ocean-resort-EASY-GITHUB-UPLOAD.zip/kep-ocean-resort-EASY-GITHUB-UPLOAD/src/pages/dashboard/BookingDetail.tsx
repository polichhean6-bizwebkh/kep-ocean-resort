import { useState } from 'react';
import { useParams, Link, Navigate, useNavigate } from 'react-router-dom';
import { ArrowLeft, Printer, Trash2 } from 'lucide-react';
import { useAppData } from '../../context/AppDataContext';
import Badge from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import ConfirmDialog from '../../components/dashboard/ConfirmDialog';
import { formatDate } from '../../lib/format';
import type { BookingRequestStatus } from '../../types';

const statusOptions: BookingRequestStatus[] = ['New', 'Contacted', 'Confirmed', 'Cancelled', 'Completed'];

export default function BookingDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { bookings, updateBooking, deleteBooking } = useAppData();
  const booking = bookings.find((b) => b.id === id);
  const [notes, setNotes] = useState(booking?.internalNotes ?? '');
  const [confirmDelete, setConfirmDelete] = useState(false);

  if (!booking) return <Navigate to="/admin/bookings" replace />;

  const setStatus = (status: BookingRequestStatus) => updateBooking(booking.id, { status });
  const saveNotes = () => updateBooking(booking.id, { internalNotes: notes });
  const handleDelete = () => {
    deleteBooking(booking.id);
    navigate('/admin/bookings');
  };

  return (
    <div className="max-w-3xl">
      <Link to="/admin/bookings" className="inline-flex items-center gap-1 text-sm text-charcoal-500 hover:text-ocean-700 mb-4">
        <ArrowLeft className="h-4 w-4" /> Back to booking requests
      </Link>

      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h1 className="font-display text-2xl font-semibold text-charcoal-900 flex items-center gap-3">
            {booking.id} <Badge>{booking.status}</Badge>
          </h1>
          <p className="text-charcoal-500 text-sm">Submitted {formatDate(booking.submittedAt)}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant="outlineLight" onClick={() => window.print()}><Printer className="h-4 w-4" /> Print</Button>
          <Button size="sm" variant="danger" onClick={() => setConfirmDelete(true)}><Trash2 className="h-4 w-4" /> Delete</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        <div className="bg-white rounded-2xl border border-charcoal-100 p-6">
          <h3 className="font-semibold text-charcoal-900 mb-3">Customer Contact Information</h3>
          <dl className="text-sm space-y-2 text-charcoal-600">
            <div className="flex justify-between"><dt className="text-charcoal-400">Name</dt><dd>{booking.fullName}</dd></div>
            <div className="flex justify-between"><dt className="text-charcoal-400">Phone</dt><dd>{booking.phone}</dd></div>
            <div className="flex justify-between"><dt className="text-charcoal-400">Email</dt><dd>{booking.email}</dd></div>
            {booking.telegramOrWhatsapp && <div className="flex justify-between"><dt className="text-charcoal-400">Telegram / WhatsApp</dt><dd>{booking.telegramOrWhatsapp}</dd></div>}
          </dl>
        </div>
        <div className="bg-white rounded-2xl border border-charcoal-100 p-6">
          <h3 className="font-semibold text-charcoal-900 mb-3">Stay Details</h3>
          <dl className="text-sm space-y-2 text-charcoal-600">
            <div className="flex justify-between"><dt className="text-charcoal-400">Preferred Villa</dt><dd>{booking.preferredVillaName}</dd></div>
            <div className="flex justify-between"><dt className="text-charcoal-400">Check-in</dt><dd>{formatDate(booking.checkIn)}</dd></div>
            <div className="flex justify-between"><dt className="text-charcoal-400">Check-out</dt><dd>{formatDate(booking.checkOut)}</dd></div>
            <div className="flex justify-between"><dt className="text-charcoal-400">Guests</dt><dd>{booking.adults} adults, {booking.children} children</dd></div>
            {booking.arrivalTime && <div className="flex justify-between"><dt className="text-charcoal-400">Arrival time</dt><dd>{booking.arrivalTime}</dd></div>}
          </dl>
        </div>
      </div>

      {booking.specialRequest && (
        <div className="bg-white rounded-2xl border border-charcoal-100 p-6 mb-6">
          <h3 className="font-semibold text-charcoal-900 mb-2">Special Request</h3>
          <p className="text-sm text-charcoal-600">{booking.specialRequest}</p>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-charcoal-100 p-6 mb-6">
        <h3 className="font-semibold text-charcoal-900 mb-3">Update Status</h3>
        <div className="flex flex-wrap gap-2">
          {statusOptions.map((s) => (
            <button
              key={s}
              onClick={() => setStatus(s)}
              className={`px-3.5 py-2 rounded-full text-xs font-medium border ${booking.status === s ? 'bg-ocean-700 text-white border-ocean-700' : 'bg-white text-charcoal-600 border-charcoal-200 hover:border-ocean-300'}`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-charcoal-100 p-6 mb-6">
        <h3 className="font-semibold text-charcoal-900 mb-3">Contact the Customer</h3>
        <p className="text-sm text-charcoal-600 mb-3">Reach out directly using the details below to confirm availability and payment.</p>
        <div className="flex flex-wrap gap-2">
          <a href={`tel:${booking.phone}`} className="text-xs font-medium bg-sand-100 text-charcoal-700 rounded-full px-3.5 py-2">Call {booking.phone}</a>
          <a href={`mailto:${booking.email}`} className="text-xs font-medium bg-sand-100 text-charcoal-700 rounded-full px-3.5 py-2">Email {booking.email}</a>
          {booking.telegramOrWhatsapp && <span className="text-xs font-medium bg-sand-100 text-charcoal-700 rounded-full px-3.5 py-2">{booking.telegramOrWhatsapp}</span>}
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-charcoal-100 p-6">
        <h3 className="font-semibold text-charcoal-900 mb-3">Internal Staff Notes</h3>
        <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} className="w-full border border-charcoal-200 rounded-lg px-3 py-2 text-sm mb-3" placeholder="Notes visible to staff only" />
        <Button size="sm" variant="outlineLight" onClick={saveNotes}>Save Notes</Button>
      </div>

      <ConfirmDialog
        open={confirmDelete}
        title="Delete this demo booking?"
        message="This permanently removes the booking request from this demo session. This does not affect any real customer data."
        confirmLabel="Delete Booking"
        onConfirm={handleDelete}
        onCancel={() => setConfirmDelete(false)}
      />
    </div>
  );
}
