import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Calendar, Users, AlertCircle } from 'lucide-react';
import { useAppData } from '../../context/AppDataContext';
import { villas } from '../../data/villas';
import { Button } from '../../components/ui/Button';
import { todayISO } from '../../lib/format';
import type { BookingRequest } from '../../types';

interface FormState {
  checkIn: string;
  checkOut: string;
  villaId: string;
  adults: number;
  children: number;
  fullName: string;
  phone: string;
  email: string;
  telegramOrWhatsapp: string;
  arrivalTime: string;
  specialRequest: string;
}

export default function BookingRequestForm() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const { bookings, addBooking } = useAppData();
  const today = todayISO();

  const [form, setForm] = useState<FormState>({
    checkIn: params.get('checkIn') || '',
    checkOut: params.get('checkOut') || '',
    villaId: villas.find((v) => v.slug === params.get('villa'))?.id || '',
    adults: Number(params.get('guests')) || 2,
    children: 0,
    fullName: '',
    phone: '',
    email: '',
    telegramOrWhatsapp: '',
    arrivalTime: '',
    specialRequest: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const update = <K extends keyof FormState>(key: K, value: FormState[K]) => setForm((f) => ({ ...f, [key]: value }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (!form.checkIn) next.checkIn = 'Check-in date is required.';
    if (!form.checkOut) next.checkOut = 'Check-out date is required.';
    if (form.checkIn && form.checkIn < today) next.checkIn = 'Check-in date cannot be in the past.';
    if (form.checkIn && form.checkOut && form.checkOut <= form.checkIn) next.checkOut = 'Check-out date must be after check-in date.';
    if (!form.villaId) next.villaId = 'Please select a preferred villa.';
    if (!form.fullName.trim()) next.fullName = 'Full name is required.';
    if (!form.phone.trim()) next.phone = 'Phone number is required.';
    if (!form.email.trim() || !form.email.includes('@')) next.email = 'A valid email is required.';

    const villa = villas.find((v) => v.id === form.villaId);
    if (villa && form.adults + form.children > villa.maxGuests) {
      next.adults = `${villa.name} sleeps up to ${villa.maxGuests} guests. Reduce guests or choose a larger villa.`;
    }

    setErrors(next);
    if (Object.keys(next).length > 0 || !villa) return;

    const id = `KOR-2026-${String(bookings.length + 1).padStart(4, '0')}`;
    const booking: BookingRequest = {
      id,
      fullName: form.fullName.trim(),
      phone: form.phone.trim(),
      email: form.email.trim(),
      telegramOrWhatsapp: form.telegramOrWhatsapp.trim() || undefined,
      preferredVillaId: villa.id,
      preferredVillaName: villa.name,
      checkIn: form.checkIn,
      checkOut: form.checkOut,
      adults: form.adults,
      children: form.children,
      arrivalTime: form.arrivalTime || undefined,
      specialRequest: form.specialRequest.trim() || undefined,
      status: 'New',
      submittedAt: today,
    };

    addBooking(booking);
    sessionStorage.setItem('kor_last_booking_request', JSON.stringify(booking));
    navigate('/book/confirmation');
  };

  return (
    <div className="bg-white rounded-3xl border border-charcoal-100 p-6 sm:p-8">
      <h1 className="font-display text-2xl sm:text-3xl font-semibold mb-2">Request a Booking</h1>
      <p className="text-charcoal-500 text-sm mb-8">
        Tell us your preferred dates and villa. Our team will contact you shortly to confirm
        availability and payment details — no payment is required now.
      </p>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <Field label="Check-in Date" error={errors.checkIn} icon={<Calendar className="h-4 w-4" />}>
            <input type="date" min={today} value={form.checkIn} onChange={(e) => update('checkIn', e.target.value)} className={inputCls(errors.checkIn)} />
          </Field>
          <Field label="Check-out Date" error={errors.checkOut} icon={<Calendar className="h-4 w-4" />}>
            <input type="date" min={form.checkIn || today} value={form.checkOut} onChange={(e) => update('checkOut', e.target.value)} className={inputCls(errors.checkOut)} />
          </Field>
        </div>

        <Field label="Preferred Villa" error={errors.villaId}>
          <select value={form.villaId} onChange={(e) => update('villaId', e.target.value)} className={inputCls(errors.villaId)}>
            <option value="">Select a villa</option>
            {villas.map((v) => <option key={v.id} value={v.id}>{v.name} — up to {v.maxGuests} guests</option>)}
          </select>
        </Field>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <Field label="Adults" error={errors.adults} icon={<Users className="h-4 w-4" />}>
            <input type="number" min={1} max={10} value={form.adults} onChange={(e) => update('adults', Math.max(1, Number(e.target.value)))} className={inputCls(errors.adults)} />
          </Field>
          <Field label="Children">
            <input type="number" min={0} max={10} value={form.children} onChange={(e) => update('children', Math.max(0, Number(e.target.value)))} className={inputCls()} />
          </Field>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <Field label="Full Name" error={errors.fullName}>
            <input value={form.fullName} onChange={(e) => update('fullName', e.target.value)} className={inputCls(errors.fullName)} placeholder="e.g. Sok Dara" />
          </Field>
          <Field label="Phone Number" error={errors.phone}>
            <input value={form.phone} onChange={(e) => update('phone', e.target.value)} className={inputCls(errors.phone)} placeholder="+855 ..." />
          </Field>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <Field label="Email" error={errors.email}>
            <input type="email" value={form.email} onChange={(e) => update('email', e.target.value)} className={inputCls(errors.email)} placeholder="you@example.com" />
          </Field>
          <Field label="Telegram or WhatsApp (optional)">
            <input value={form.telegramOrWhatsapp} onChange={(e) => update('telegramOrWhatsapp', e.target.value)} className={inputCls()} placeholder="@username or number" />
          </Field>
        </div>

        <Field label="Expected Arrival Time (optional)">
          <input type="time" value={form.arrivalTime} onChange={(e) => update('arrivalTime', e.target.value)} className={inputCls()} />
        </Field>

        <Field label="Special Request (optional)">
          <textarea value={form.specialRequest} onChange={(e) => update('specialRequest', e.target.value)} rows={3} className={inputCls()} placeholder="Anything we should know?" />
        </Field>

        {Object.keys(errors).length > 0 && (
          <div className="flex items-center gap-2 bg-red-50 border border-red-100 text-red-700 rounded-lg px-4 py-3 text-sm">
            <AlertCircle className="h-4 w-4 shrink-0" /> Please correct the highlighted fields.
          </div>
        )}

        <Button type="submit" size="lg" className="w-full sm:w-auto">Submit Booking Request</Button>
        <p className="text-xs text-charcoal-400">This is a request only — no payment is taken now. Our team will contact you to confirm.</p>
      </form>
    </div>
  );
}

function inputCls(error?: string) {
  return `w-full border rounded-lg px-4 py-2.5 text-sm ${error ? 'border-red-400' : 'border-charcoal-200'}`;
}

function Field({ label, error, icon, children }: { label: string; error?: string; icon?: React.ReactNode; children: React.ReactNode }) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-sm font-medium text-charcoal-700 flex items-center gap-1.5">{icon} {label}</span>
      {children}
      {error && <span className="text-red-600 text-xs">{error}</span>}
    </label>
  );
}
