import { Outlet, Link } from 'react-router-dom';
import { Waves } from 'lucide-react';
import Container from '../../components/ui/Container';

export default function BookingLayout() {
  return (
    <div className="min-h-screen bg-sand-50 flex flex-col">
      <header className="bg-white border-b border-charcoal-100 sticky top-0 z-30">
        <Container className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-ocean-700"><Waves className="h-4 w-4 text-white" /></span>
            <span className="font-display font-semibold text-charcoal-900">Kep Ocean Resort</span>
          </Link>
          <span className="text-xs text-charcoal-400 hidden sm:inline">Booking request — no payment is taken online</span>
        </Container>
      </header>

      <main className="flex-1 py-8 sm:py-12">
        <Container className="max-w-2xl">
          <Outlet />
        </Container>
      </main>
    </div>
  );
}
